# FCC: 
# CE:
# REACH: 
# Export control:
 * https://github.com/beagleboard/BeagleBone-Black/blob/master/regulatory/BeagleBone-Export-Info.pdf
 * ECCN: 5A002A1
 * CCATS: G141473
